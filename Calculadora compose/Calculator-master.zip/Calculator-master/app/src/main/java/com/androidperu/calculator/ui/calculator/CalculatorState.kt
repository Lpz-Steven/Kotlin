package com.androidperu.calculator.ui.calculator

data class CalculatorState(
    val text: String = ""
)
