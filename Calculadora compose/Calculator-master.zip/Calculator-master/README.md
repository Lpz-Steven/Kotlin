# Calculator
Calculator is an application that mimics the basic operations of a real life calculator. Perform operations of multiplication, division, subtraction, addition. It is developed with Jetpack compose and the Rhino library.

[![Android-Emulator-Pixel-2-API-30-5554-9-02-2022-15-39-32-preview-rev-1.png](https://i.postimg.cc/9MYJrHwL/Android-Emulator-Pixel-2-API-30-5554-9-02-2022-15-39-32-preview-rev-1.png)](https://postimg.cc/47nzSM5c)  [![Screenshot-9-02-2022-15-37-32-preview-rev-1.png](https://i.postimg.cc/02wKfdcs/Screenshot-9-02-2022-15-37-32-preview-rev-1.png)](https://postimg.cc/tY9gR6KS)
